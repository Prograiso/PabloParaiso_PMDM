package com.example.examenfinal1t.model

import java.io.Serializable

class Tarea (
    var nombre : String,
    var descripcion: String,
    var importancia: String,
    var imagenImportancia: String

) : Serializable {
}